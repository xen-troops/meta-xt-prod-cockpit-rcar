#!/bin/sh

# $Id: narrowmerge.sh,v 1.1 2005/01/20 21:57:05 src Exp $

for tofile in *Condensed*.sfd; do
  fromfile=`echo $tofile | sed 's,Condensed,,'`
  ./narrowmerge.pe 90 $tofile.merged `./merge.pl $fromfile $tofile $tofile.merged`
  if [ -e $tofile.merged ]; then
    rm $tofile.merged
  fi
done
