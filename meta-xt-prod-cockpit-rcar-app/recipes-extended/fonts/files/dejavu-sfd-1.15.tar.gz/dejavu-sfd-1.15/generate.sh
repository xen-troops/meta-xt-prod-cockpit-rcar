#!/bin/sh

# $Id: generate.sh,v 1.3 2005/05/27 22:41:47 src Exp $

mkdir generated
./generate.pe *.sfd
./ttpostproc.pl generated/*.ttf
