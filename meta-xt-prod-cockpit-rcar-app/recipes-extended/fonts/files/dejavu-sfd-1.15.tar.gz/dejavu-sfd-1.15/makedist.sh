#!/bin/sh

# $Id: makedist.sh,v 1.5 2005/09/13 21:24:10 src Exp $

version=$1
echo Making distribution of DejaVu fonts $version
mkdir packaged
mkdir packaged/dejavu-sfd-$version
cp *.sfd *.pe *.me *.sh *.pl README LICENSE AUTHORS NEWS BUGS *.txt packaged/dejavu-sfd-$version
(cd packaged; tar czvf dejavu-sfd-$version.tar.gz dejavu-sfd-$version)
mkdir packaged/dejavu-ttf-$version
cp generated/*.ttf README LICENSE AUTHORS NEWS BUGS *.txt packaged/dejavu-ttf-$version
(cd packaged; tar czvf dejavu-ttf-$version.tar.gz dejavu-ttf-$version)
(cd packaged; zip -rv dejavu-ttf-$version.zip dejavu-ttf-$version)
